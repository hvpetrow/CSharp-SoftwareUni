﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            List<IBirthdayable> members = new List<IBirthdayable>();

            while (true)
            {
                string input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }

                string[] parts = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string command = parts[0];

                if (command=="Citizen")
                {
                    string name = parts[1];
                    int age = int.Parse(parts[2]);
                    string id = parts[3];
                    string birthdate = parts[4];
                   IBirthdayable member = new Citizen(name,age,id,birthdate);
                    members.Add(member);

                }
                else if(command=="Robot")
                {
                    string model = parts[1];
                    string id = parts[2];
                    Robot robot = new Robot(model , id);
                }
                else if (command == "Pet")
                {
                    string name = parts[1];
                    string birthday = parts[2];
                   IBirthdayable member = new Pet(name,birthday);
                    members.Add(member);
                }

            }

            string specifiedYear = Console.ReadLine();

            foreach (var member in members)
            {
                if (member.Birthday.EndsWith(specifiedYear))
                {
                    Console.WriteLine(member.Birthday);
                }
                //string endDigits = member.Id.Substring(member.Id.Length - 3);
                //if (endDigits ==   searchedEndNumber)
                //{
                //    Console.WriteLine(member.Id);
                //}
            }
        }
    }
}
