﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> members = new List<IIdentifiable>();

            while (true)
            {
                string input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }

                string[] parts = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                IIdentifiable member = null;

                if (parts.Length == 3)
                {
                    string name = parts[0];
                    int age = int.Parse(parts[1]);
                    string id = parts[2];
                    member = new Citizen(name,age,id);
                }
                else if(parts.Length==2)
                {
                    string model = parts[0];
                    string id = parts[1];
                    member = new Robot(model, id);
                }
                    members.Add(member);
            }

            string searchedEndNumber = Console.ReadLine();

            foreach (var member in members)
            {
                if (member.Id.EndsWith(searchedEndNumber))
                {
                    Console.WriteLine(member.Id);
                }
                //string endDigits = member.Id.Substring(member.Id.Length - 3);
                //if (endDigits ==   searchedEndNumber)
                //{
                //    Console.WriteLine(member.Id);
                //}
            }
        }
    }
}
