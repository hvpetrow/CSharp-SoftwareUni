﻿using System;

namespace PersonInfo
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            string name = Console.ReadLine();
            int age = int.Parse(Console.ReadLine());
            IPerson person = new Citizen(name, age);
            var citizen = new Citizen(name, age);
            person.Run();
            citizen.Run();
            Console.WriteLine(person.Name);
            Console.WriteLine(person.Age);
        }
    }
}
