﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Raiding
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            Dictionary<string,List<string>> raid = new Dictionary<string, List<string>>
            {
                {"druid",    new List<string>( )},
                { "paladin", new List<string>( )},
                { "rogue" ,  new List<string>( )},
                { "warrior", new List<string>()}
            };

            List<int> raidPower = new List<int>();

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string heroName = Console.ReadLine();
                string heroType = Console.ReadLine().ToLower();

                if (!raid.ContainsKey(heroType))
                {
                    Console.WriteLine("Invalid hero!");
                    continue;
                }
               
                if (raid[heroType].Any(h=>h == heroName))
                {
                    continue;
                }

                raid[heroType].Add(heroName);


                BaseHero hero = null;
                if (heroType=="paladin")
                {
                    hero = new Paladin(heroName);
                }
                else if (heroType== "druid")
                {
                    hero = new Druid(heroName);

                }
                else if (heroType == "rogue")
                {
                     hero = new Rogue(heroName);

                }
                else if (heroType == "warrior")
                {
                   hero = new Warrior(heroName);

                }

                raidPower.Add(hero.Power);
                Console.WriteLine(hero.CastAbility());
                
            }

            int bossPower = int.Parse(Console.ReadLine());

            if (raidPower.Sum() >= bossPower)
            {
                Console.WriteLine("Victory!");
            }
            else
            {
                Console.WriteLine("Defeat...");
            }
        }
    }
}


