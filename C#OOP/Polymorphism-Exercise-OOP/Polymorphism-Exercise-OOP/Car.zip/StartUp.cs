﻿using System;

namespace Vehicles
{
   public class StartUp
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            double carFuelQuantity = double.Parse(carInfo[1]);
            double carFuelConsumption = double.Parse(carInfo[2]);

            string[] truckInfo = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            double truckFuelQuantity = double.Parse(truckInfo[1]);
            double truckFuelConsumption = double.Parse(truckInfo[2]);

            IDriveable car = new Car(carFuelQuantity,carFuelConsumption);
            IDriveable truck = new Truck(truckFuelQuantity,truckFuelConsumption);

            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                string[] parts = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string command = parts[0];
                string vehicle = parts[1];

                if (vehicle== "Truck")
                {
                    if (command == "Drive")
                    {
                        double truckDistance = double.Parse(parts[2]);
                        Console.WriteLine(truck.Drive(truckDistance)); 
                    }
                    else if (command == "Refuel")
                    {
                        double fuel = double.Parse(parts[2]);
                        truck.Refuel(fuel);
                    }
                }
                else if (vehicle == "Car")
                {
                    if (command == "Drive")
                    {
                        double carDistance = double.Parse(parts[2]);
                        Console.WriteLine(car.Drive(carDistance)); 
                    }
                    else if (command == "Refuel")
                    {
                        double fuel = double.Parse(parts[2]);
                        car.Refuel(fuel);
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:F2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
        }
    }
}
