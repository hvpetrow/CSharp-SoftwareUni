﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : IDriveable
    {
        public Car(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get; private set; }
        public double FuelConsumption { get; }

        public void Refuel(double fuel)
        {
            FuelQuantity += fuel;
        }

        public string Drive(double distance)
        {
            if (FuelQuantity < (FuelConsumption + 0.9) * distance)
            {
                return $"Car needs refueling";
            }
            else
            {
                FuelQuantity -= (FuelConsumption + 0.9) * distance;
                return $"Car travelled {distance} km";
            }
        }
    }
}
