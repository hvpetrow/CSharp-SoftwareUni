﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : IDriveable
    {
        public Truck(double fuelQuantity, double fuelConsumption)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
        }

        public double FuelQuantity { get;private set; }
        public double FuelConsumption { get; }

        public void Refuel(double fuel)
        {
            FuelQuantity += fuel * 0.95;
        }

        public string Drive(double distance)
        {
            if (FuelQuantity<(FuelConsumption+1.6)*distance)
            {
                return $"Truck needs refueling";
            }
            else
            {
                FuelQuantity -= (FuelConsumption + 1.6) * distance;
                return $"Truck travelled {distance} km";
            }
        }
    }
}
