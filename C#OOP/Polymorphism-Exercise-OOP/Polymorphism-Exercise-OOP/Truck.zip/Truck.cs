﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Truck : IDriveable
    {
        private int tankCapacity;

        public Truck(double fuelQuantity, double fuelConsumption, int tankCapacity)
        {
            FuelQuantity = fuelQuantity;
            FuelConsumption = fuelConsumption;
            TankCapacity = tankCapacity;
        }



        public double FuelQuantity { get; private set; }
        public double FuelConsumption { get; }
        public int TankCapacity
        {
            get => tankCapacity;
            private set
            {
                if (FuelQuantity > value)
                {
                    FuelQuantity = 0;
                }
                tankCapacity = value;
            }
        }

        public void Refuel(double fuel)
        {
            // FuelQuantity += fuel * 0.95;

            if (fuel <= 0)
            {
                Console.WriteLine("Fuel must be a positive number");

            }
            else if (FuelQuantity + fuel > tankCapacity)
            {
                Console.WriteLine($"Cannot fit {fuel} fuel in the tank");
            }
            else
            {
                FuelQuantity += fuel * 0.95;
            }
        }

        public string Drive(double distance)
        {

            if (FuelQuantity < (FuelConsumption + 1.6) * distance)
            {
                return $"Truck needs refueling";
            }
            else
            {
                FuelQuantity -= (FuelConsumption + 1.6) * distance;
                return $"Truck travelled {distance} km";
            }
        }
    }
}
