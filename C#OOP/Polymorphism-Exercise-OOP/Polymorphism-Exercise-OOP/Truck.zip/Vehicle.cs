﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle : IDriveable
    {
        public double FuelQuantity => throw new NotImplementedException();

        public double FuelConsumption => throw new NotImplementedException();

        public int TankCapacity => throw new NotImplementedException();

        public string Drive(double distance)
        {
            throw new NotImplementedException();
        }

        public void Refuel(double fuel)
        {
            throw new NotImplementedException();
        }
    }
}
