﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericBoxOfString
{
    public class Box<T> 
    where T : IComparable<T>
    {
        
        private T data;
        
        public Box(T value)
        {
            data=value;
        }
         

        public override string ToString()
        {
            return $"{this.data.GetType().FullName}: {this.data} ";
        }

        public int CompareTo(T other)
        {
            return data.CompareTo(other);
        }

    }
}
